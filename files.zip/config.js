/* ============================================================
   NETHERIA MC SMP — SITE CONFIGURATION
   ============================================================
   This is the ONLY file you need to touch to change the text,
   links, server details, features, FAQ, rules and staff shown
   on the website. The rest of the site (script.js) reads this
   file and builds the page automatically.

   HOW TO EDIT:
   - Text goes between quotes "like this"
   - Keep the commas between items
   - Don't delete the curly braces { } or square brackets [ ]
   - If you're not sure, only change the text inside the quotes
   ============================================================ */

const NETHERIA_CONFIG = {

  /* ---------- GENERAL SERVER INFO ---------- */
  server: {
    name: "Netheria MC SMP",
    tagline: "Your adventure begins here.",
    description:
      "Netheria MC SMP is a community-driven Minecraft survival experience where players can build, explore, trade, create friendships and write their own story.",

    // Java Edition connection address (shown + copyable on the site)
    ipJava: "play.netheria.net",

    // Bedrock Edition connection address + port (Bedrock always needs a port)
    ipBedrock: "play.netheria.net",
    portBedrock: "19132",

    // Port for Java (only shown if not the default 25565)
    portJava: "25565",

    version: "1.21.x  (Java + Bedrock via Geyser)",

    // "online" or "offline" — controls the status dot/colour.
    // Replace the whole status block below with a live API call
    // if you want real numbers (see README.md, "Live server status").
    status: "online",
    playersOnline: 128,
    playersMax: 250,
  },

  /* ---------- SOCIAL / COMMUNITY LINKS ---------- */
  links: {
    discord: "https://discord.gg/your-invite-code",
    youtube: "https://youtube.com/@your-channel",
    tiktok: "https://tiktok.com/@your-handle",
  },

  /* ---------- MUSIC ---------- */
  // Put your own royalty-free .mp3 or .ogg file in /assets/music/
  // and change the file name below. Keep it royalty-free / your own work.
  music: {
    file: "assets/music/theme.mp3",
    trackName: "Netheria Theme",
  },

  /* ---------- FEATURES SECTION ---------- */
  // Icons use simple inline emoji/glyphs so nothing extra needs installing.
  // Swap the "icon" value for any emoji or single character you like.
  features: [
    {
      icon: "⛏️",
      title: "Survival SMP",
      text: "A classic, vanilla-friendly survival world with light custom tweaks — no pay-to-win, just you, your friends and the world.",
    },
    {
      icon: "💰",
      title: "Player Economy",
      text: "Earn currency through jobs, trading and quests, then spend it at player-run shops or the marketplace.",
    },
    {
      icon: "🏪",
      title: "Player Shops",
      text: "Open your own shop, set your own prices and build a trading empire in the Netheria marketplace district.",
    },
    {
      icon: "📜",
      title: "Quests",
      text: "Daily and story quests send you across the map for exclusive rewards, cosmetics and rare loot.",
    },
    {
      icon: "🎉",
      title: "Seasonal Events",
      text: "Build competitions, PvP tournaments and holiday events keep every season on Netheria feeling fresh.",
    },
    {
      icon: "🤝",
      title: "Friendly Community",
      text: "An active, welcoming Discord and in-game community with helpful staff and regular community nights.",
    },
    {
      icon: "🏅",
      title: "Rank Progression",
      text: "Play, contribute and vote to unlock ranks, perks and cosmetic rewards as you grow with the server.",
    },
    {
      icon: "⚙️",
      title: "Custom Features",
      text: "Hand-picked plugins add quality-of-life and new systems without breaking the vanilla survival feel.",
    },
    {
      icon: "📱",
      title: "Java + Bedrock",
      text: "Play from PC, console or mobile — Netheria supports full crossplay between Java and Bedrock editions.",
    },
  ],

  /* ---------- HOW TO PLAY (3 steps) ---------- */
  howToPlay: {
    java: {
      label: "Java Edition",
      steps: [
        "Open Minecraft: Java Edition and go to Multiplayer.",
        "Click \"Add Server\" and enter the address play.netheria.net",
        "Click Join Server and start your adventure!",
      ],
    },
    bedrock: {
      label: "Bedrock Edition",
      steps: [
        "Open Minecraft on console, mobile or Windows.",
        "Go to Servers and add play.netheria.net on port 19132",
        "Select Netheria MC SMP and tap Join!",
      ],
    },
  },

  /* ---------- FAQ ---------- */
  faq: [
    {
      q: "What is Netheria MC SMP?",
      a: "Netheria is a community-run Minecraft survival server (SMP) focused on building, trading, quests and making friends in a shared, persistent world.",
    },
    {
      q: "What Minecraft versions are supported?",
      a: "We currently support Minecraft Java Edition 1.21.x and all recent Bedrock versions through cross-play. Check the Server Information section above for the exact version.",
    },
    {
      q: "Is the server free?",
      a: "Yes! Netheria is completely free to join. Optional cosmetic ranks are available to support the server, but nothing is pay-to-win.",
    },
    {
      q: "Can Bedrock players join?",
      a: "Absolutely. Netheria supports full crossplay between Java and Bedrock Edition using Geyser, so console, mobile and PC players can play together.",
    },
    {
      q: "How do I join?",
      a: "Copy the server IP from the Server Information section, add it to your multiplayer server list, and connect. See the \"How To Play\" section for a step-by-step guide.",
    },
    {
      q: "Where can I get support?",
      a: "Join our Discord community and open a support ticket in the #help channel — our staff team is active and happy to help.",
    },
    {
      q: "How can I become staff?",
      a: "We open staff applications periodically on our Discord. Being active, helpful and respectful in the community is the best way to get noticed.",
    },
  ],

  /* ---------- RULES ---------- */
  rules: [
    "Be respectful to every player and staff member — harassment, hate speech and discrimination are not tolerated.",
    "No griefing, stealing or destroying other players' builds without permission.",
    "Cheating, hacked clients, X-ray texture packs and exploiting bugs are strictly forbidden.",
    "Keep chat clean — no spamming, excessive caps or advertising other servers.",
    "Builds must follow our content guidelines — no NSFW, offensive or hateful structures.",
    "Trading scams and impersonating staff are punishable by a permanent ban.",
    "Staff decisions are final; use the Discord ticket system to appeal or ask questions.",
  ],

  /* ---------- STAFF / TEAM ---------- */
  // Replace "image" with a path like "assets/images/staff/yourname.png"
  // Leave it empty ("") to show a placeholder avatar instead.
  staff: [
    { name: "OwnerName", role: "Owner", image: "" },
    { name: "AdminName", role: "Admin", image: "" },
    { name: "AdminTwo", role: "Admin", image: "" },
    { name: "ModName", role: "Moderator", image: "" },
    { name: "ModTwo", role: "Moderator", image: "" },
    { name: "HelperName", role: "Staff", image: "" },
  ],
};
