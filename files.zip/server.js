/* ============================================================
   NETHERIA MC SMP — SERVER
   ------------------------------------------------------------
   A tiny Express server that serves the website's static files
   (index.html, style.css, script.js, config.js, assets/...).
   This is the file Glitch runs to start your project.

   You do NOT need to edit this file to change your site content
   — edit config.js instead.
   ============================================================ */

const express = require("express");
const path = require("path");

const app = express();

// Serve every file in this folder (index.html, style.css, script.js,
// config.js, and everything inside /assets) as a static file.
app.use(express.static(path.join(__dirname, "/")));

// Fallback: any unknown route just sends back the homepage.
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// Glitch (and most hosts) provide the port via process.env.PORT.
// 3000 is used automatically when running locally.
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Netheria MC SMP website running on port ${PORT}`);
});
