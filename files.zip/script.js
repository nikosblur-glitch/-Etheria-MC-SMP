/* ============================================================
   NETHERIA MC SMP — SITE SCRIPT
   ------------------------------------------------------------
   This file reads NETHERIA_CONFIG (from config.js) and:
   1. Fills in all the text/links on the page
   2. Builds the Features, FAQ, Rules and Staff sections
   3. Powers all the interactive bits (menu, music, copy, etc.)

   You should not need to edit this file to update your site's
   content — edit config.js instead. This file is commented in
   case you DO want to tweak behaviour.
   ============================================================ */

document.addEventListener("DOMContentLoaded", () => {
  const CONFIG = window.NETHERIA_CONFIG;

  /* ============================================================
     1. RENDER CONTENT FROM CONFIG
     ============================================================ */
  function renderContent() {
    const { server, links, faq, rules, staff, features, howToPlay, music } = CONFIG;

    // Document title / meta bits stay in index.html, but text nodes
    // that should reflect config live here.
    document.title = `${server.name} — ${server.tagline}`;

    // Hero
    setText("hero-tagline", server.tagline);
    setText("hero-ip", server.ipJava);
    setText("hero-version", server.version.split("(")[0].trim());
    setLink("hero-discord", links.discord);

    // Status strip (hero) + server info panel
    updateStatus(server);

    // About
    setText("about-text", server.description);

    // Server info panel
    setText("info-name", server.name);
    setText("ip-java", server.ipJava);
    setText("ip-bedrock", `${server.ipBedrock}:${server.portBedrock}`);
    setText(
      "info-port",
      `${server.portJava} (Java) · ${server.portBedrock} (Bedrock)`
    );
    setText("info-version", server.version);
    setLink("info-discord", links.discord);
    setTextContent("info-discord", links.discord.replace(/^https?:\/\//, ""));

    // Community section
    setLink("community-discord", links.discord);

    // Footer
    setLink("footer-discord", links.discord);
    setLink("footer-youtube", links.youtube);
    setLink("footer-tiktok", links.tiktok);
    setText("footer-year", new Date().getFullYear());

    // Feature cards
    const featureGrid = document.getElementById("feature-grid");
    featureGrid.innerHTML = features
      .map(
        (f) => `
        <article class="feature-card reveal">
          <div class="feature-card__icon" aria-hidden="true">${f.icon}</div>
          <h3 class="feature-card__title">${escapeHTML(f.title)}</h3>
          <p class="feature-card__text">${escapeHTML(f.text)}</p>
        </article>`
      )
      .join("");

    // How to play steps (default: java)
    renderHowToPlay("java");

    // FAQ accordion
    const faqList = document.getElementById("faq-list");
    faqList.innerHTML = faq
      .map(
        (item, i) => `
        <div class="faq-item" id="faq-${i}">
          <button class="faq-item__q" aria-expanded="false" aria-controls="faq-a-${i}">
            <span>${escapeHTML(item.q)}</span>
            <span class="faq-item__icon" aria-hidden="true">+</span>
          </button>
          <div class="faq-item__a" id="faq-a-${i}">
            <p>${escapeHTML(item.a)}</p>
          </div>
        </div>`
      )
      .join("");

    // Rules list
    const rulesList = document.getElementById("rules-list");
    rulesList.innerHTML = rules
      .map((rule) => `<li>${escapeHTML(rule)}</li>`)
      .join("");

    // Staff grid
    const staffGrid = document.getElementById("staff-grid");
    staffGrid.innerHTML = staff
      .map((member) => {
        const initials = member.name
          .split(" ")
          .map((w) => w[0])
          .join("")
          .slice(0, 2)
          .toUpperCase();
        const avatar = member.image
          ? `<img src="${member.image}" alt="${escapeHTML(member.name)}" />`
          : initials;
        return `
        <div class="staff-card reveal">
          <div class="staff-card__avatar">${avatar}</div>
          <div class="staff-card__name">${escapeHTML(member.name)}</div>
          <div class="staff-card__role">${escapeHTML(member.role)}</div>
        </div>`;
      })
      .join("");

    // Music player labels
    setText("music-track-name", music.trackName);
    document.getElementById("bg-music").src = music.file;
  }

  function renderHowToPlay(edition) {
    const stepsData = CONFIG.howToPlay[edition].steps;
    const container = document.getElementById("howto-steps");
    container.innerHTML = stepsData
      .map((step) => `<li class="howto-step"><p>${escapeHTML(step)}</p></li>`)
      .join("");
  }

  function updateStatus(server) {
    const isOnline = server.status === "online";

    ["status-dot", "status-dot-2"].forEach((id) => {
      const dot = document.getElementById(id);
      if (dot) dot.classList.toggle("is-offline", !isOnline);
    });
    setText("status-text", isOnline ? "Online" : "Offline");
    setText("status-text-2", isOnline ? "Online" : "Offline");

    setText("players-max", server.playersMax);
    animateCounter(document.getElementById("players-count"), server.playersOnline, 900);
  }

  /* ---------- small DOM helpers ---------- */
  function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  }
  function setTextContent(id, value) {
    setText(id, value);
  }
  function setLink(id, href) {
    const el = document.getElementById(id);
    if (el) el.href = href;
  }
  function escapeHTML(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  renderContent();

  /* ============================================================
     2. LOADING SCREEN
     ============================================================ */
  const loadingScreen = document.getElementById("loading-screen");
  window.addEventListener("load", () => {
    setTimeout(() => loadingScreen.classList.add("is-hidden"), 500);
  });
  // Safety net in case the load event already fired / is slow to trigger
  setTimeout(() => loadingScreen.classList.add("is-hidden"), 3500);

  /* ============================================================
     3. NAV — scroll state, mobile menu, active link
     ============================================================ */
  const nav = document.getElementById("site-nav");
  const hamburger = document.getElementById("hamburger");
  const mobileMenu = document.getElementById("mobile-menu");

  window.addEventListener("scroll", () => {
    nav.classList.toggle("is-scrolled", window.scrollY > 20);
    toggleBackToTop();
  }, { passive: true });

  hamburger.addEventListener("click", () => {
    const isOpen = mobileMenu.classList.toggle("is-open");
    hamburger.classList.toggle("is-open", isOpen);
    hamburger.setAttribute("aria-expanded", String(isOpen));
  });

  mobileMenu.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      mobileMenu.classList.remove("is-open");
      hamburger.classList.remove("is-open");
      hamburger.setAttribute("aria-expanded", "false");
    });
  });

  /* ============================================================
     4. HOW TO PLAY TABS
     ============================================================ */
  document.querySelectorAll(".howto-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      document.querySelectorAll(".howto-tab").forEach((t) => t.classList.remove("is-active"));
      tab.classList.add("is-active");
      renderHowToPlay(tab.dataset.edition);
      // Re-observe the freshly injected steps so they still reveal nicely
      document.querySelectorAll("#howto-steps .howto-step").forEach((el) => el.classList.add("is-visible"));
    });
  });

  /* ============================================================
     5. FAQ ACCORDION
     ============================================================ */
  document.getElementById("faq-list").addEventListener("click", (e) => {
    const question = e.target.closest(".faq-item__q");
    if (!question) return;
    const item = question.closest(".faq-item");
    const answer = item.querySelector(".faq-item__a");
    const isOpen = item.classList.contains("is-open");

    // Close any other open item (accordion behaviour)
    document.querySelectorAll(".faq-item.is-open").forEach((openItem) => {
      if (openItem !== item) {
        openItem.classList.remove("is-open");
        openItem.querySelector(".faq-item__a").style.maxHeight = null;
        openItem.querySelector(".faq-item__q").setAttribute("aria-expanded", "false");
      }
    });

    item.classList.toggle("is-open", !isOpen);
    question.setAttribute("aria-expanded", String(!isOpen));
    answer.style.maxHeight = !isOpen ? answer.scrollHeight + "px" : null;
  });

  /* ============================================================
     6. COPY SERVER IP BUTTONS
     ============================================================ */
  document.body.addEventListener("click", (e) => {
    const btn = e.target.closest(".copy-btn");
    if (!btn) return;
    const targetId = btn.dataset.copyTarget;
    const targetEl = document.getElementById(targetId);
    if (!targetEl) return;

    const text = targetEl.textContent.trim();
    copyToClipboard(text).then(() => {
      const originalLabel = btn.textContent;
      btn.classList.add("is-copied");
      if (originalLabel.trim().length > 0 && originalLabel.trim() !== "") {
        btn.textContent = "Copied!";
      }
      showToast(`Server IP copied: ${text}`, "success");
      setTimeout(() => {
        btn.classList.remove("is-copied");
        if (originalLabel.trim() !== "") btn.textContent = originalLabel;
      }, 1800);
    });
  });

  function copyToClipboard(text) {
    if (navigator.clipboard && window.isSecureContext) {
      return navigator.clipboard.writeText(text);
    }
    // Fallback for older browsers / non-HTTPS contexts
    return new Promise((resolve) => {
      const temp = document.createElement("textarea");
      temp.value = text;
      temp.style.position = "fixed";
      temp.style.opacity = "0";
      document.body.appendChild(temp);
      temp.select();
      document.execCommand("copy");
      document.body.removeChild(temp);
      resolve();
    });
  }

  /* ============================================================
     7. TOAST NOTIFICATIONS
     ============================================================ */
  function showToast(message, type = "") {
    const container = document.getElementById("toast-container");
    const toast = document.createElement("div");
    toast.className = `toast${type ? " toast--" + type : ""}`;
    toast.textContent = message;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("is-leaving");
      toast.addEventListener("animationend", () => toast.remove());
    }, 2600);
  }

  /* ============================================================
     8. SCROLL REVEAL ANIMATIONS
     ============================================================ */
  const revealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          revealObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
  );
  document.querySelectorAll(".reveal").forEach((el) => revealObserver.observe(el));
  // Anything rendered dynamically inside .reveal containers (cards) also fades in
  document.querySelectorAll(".feature-card, .staff-card").forEach((el) => {
    el.classList.add("reveal");
    revealObserver.observe(el);
  });

  /* ============================================================
     9. ANIMATED COUNTERS (About section stats)
     ============================================================ */
  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          animateCounter(entry.target, Number(entry.target.dataset.count), 1600);
          counterObserver.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.6 }
  );
  document.querySelectorAll(".stat__num").forEach((el) => counterObserver.observe(el));

  function animateCounter(el, target, duration) {
    if (!el) return;
    const start = 0;
    const startTime = performance.now();

    function tick(now) {
      const progress = Math.min((now - startTime) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3); // ease-out-cubic
      const value = Math.floor(start + (target - start) * eased);
      el.textContent = value.toLocaleString();
      if (progress < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }

  /* ============================================================
     10. BACK TO TOP BUTTON
     ============================================================ */
  const backToTop = document.getElementById("back-to-top");
  function toggleBackToTop() {
    backToTop.classList.toggle("is-visible", window.scrollY > 500);
  }
  backToTop.addEventListener("click", () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  });

  /* ============================================================
     11. MUSIC PLAYER
     ------------------------------------------------------------
     - Never autoplays (browsers block it anyway; we respect that).
     - Starts only after the visitor clicks the music button.
     - Volume slider + mute/unmute toggle.
     ============================================================ */
  const music = document.getElementById("bg-music");
  const musicToggle = document.getElementById("music-toggle");
  const musicPlayerWidget = document.getElementById("music-player");
  const musicVolume = document.getElementById("music-volume");
  const iconOn = musicToggle.querySelector(".icon-music-on");
  const iconOff = musicToggle.querySelector(".icon-music-off");

  music.volume = Number(musicVolume.value);

  musicToggle.addEventListener("click", () => {
    if (music.paused) {
      music.play()
        .then(() => {
          setMusicState(true);
        })
        .catch(() => {
          showToast("Add a music file in assets/music to enable playback.");
        });
    } else {
      music.pause();
      setMusicState(false);
    }
  });

  musicVolume.addEventListener("input", () => {
    music.volume = Number(musicVolume.value);
  });

  function setMusicState(isPlaying) {
    musicToggle.classList.toggle("is-playing", isPlaying);
    musicToggle.setAttribute("aria-pressed", String(isPlaying));
    musicToggle.setAttribute("aria-label", isPlaying ? "Pause background music" : "Play background music");
    iconOn.hidden = isPlaying;
    iconOff.hidden = !isPlaying;
    musicPlayerWidget.hidden = !isPlaying;
  }

  /* ============================================================
     12. AMBIENT EMBER PARTICLE BACKGROUND
     ------------------------------------------------------------
     Lightweight canvas particle system — small rising embers to
     match the Nether theme. Pauses off-screen / reduced-motion.
     ============================================================ */
  const canvas = document.getElementById("ember-canvas");
  const ctx = canvas.getContext("2d");
  const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  let embers = [];
  let dpr = Math.min(window.devicePixelRatio || 1, 2);

  function resizeCanvas() {
    canvas.width = window.innerWidth * dpr;
    canvas.height = window.innerHeight * dpr;
    canvas.style.width = window.innerWidth + "px";
    canvas.style.height = window.innerHeight + "px";
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  function createEmbers() {
    const count = Math.min(Math.floor(window.innerWidth / 22), 70);
    embers = Array.from({ length: count }, () => spawnEmber(true));
  }

  function spawnEmber(randomY) {
    const colors = ["255,106,61", "155,92,246", "255,207,107"];
    return {
      x: Math.random() * window.innerWidth,
      y: randomY ? Math.random() * window.innerHeight : window.innerHeight + 20,
      r: Math.random() * 1.8 + 0.6,
      speed: Math.random() * 0.5 + 0.2,
      drift: Math.random() * 0.6 - 0.3,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: Math.random() * 0.5 + 0.2,
      flicker: Math.random() * 0.02 + 0.01,
    };
  }

  function drawEmbers() {
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    embers.forEach((e) => {
      e.y -= e.speed;
      e.x += Math.sin(e.y * 0.01) * e.drift * 0.4;
      e.alpha += (Math.random() - 0.5) * e.flicker;
      e.alpha = Math.max(0.1, Math.min(0.75, e.alpha));

      if (e.y < -20) Object.assign(e, spawnEmber(false));

      ctx.beginPath();
      ctx.arc(e.x, e.y, e.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${e.color}, ${e.alpha})`;
      ctx.shadowBlur = 6;
      ctx.shadowColor = `rgba(${e.color}, ${e.alpha})`;
      ctx.fill();
    });
    animationFrameId = requestAnimationFrame(drawEmbers);
  }

  let animationFrameId;
  if (!prefersReducedMotion) {
    resizeCanvas();
    createEmbers();
    animationFrameId = requestAnimationFrame(drawEmbers);
    window.addEventListener("resize", () => {
      resizeCanvas();
      createEmbers();
    });
  }

  // Pause the particle loop when the tab isn't visible (saves battery/CPU)
  document.addEventListener("visibilitychange", () => {
    if (prefersReducedMotion) return;
    if (document.hidden) {
      cancelAnimationFrame(animationFrameId);
    } else {
      animationFrameId = requestAnimationFrame(drawEmbers);
    }
  });
});
