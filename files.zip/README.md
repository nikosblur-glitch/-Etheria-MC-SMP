# Netheria MC SMP — Website

A complete, animated, dark "Nether-glassmorphism" website for a Minecraft SMP
server. Pure HTML/CSS/JS on the front end, with a tiny Express server so it
runs great on **Glitch** (or any Node host).

---

## 1. Folder structure

```
/netheria-website
├── index.html          → the page structure (all sections)
├── style.css            → all styling / design / animations
├── script.js             → all interactivity (menu, music, FAQ, etc.)
├── config.js              → ⭐ EDIT THIS to change your content ⭐
├── server.js               → tiny Express server (for Glitch/Node hosting)
├── package.json              → tells Node/Glitch how to run the site
├── README.md                   → this file
└── /assets
    ├── /images    → staff photos, screenshots, og-cover.jpg
    ├── /music     → your background music file
    └── /icons     → favicon.svg (site icon)
```

**You will spend 95% of your time editing `config.js` only.** Everything on
the page — server IP, Discord link, features, FAQ, rules, staff — is pulled
from that one file automatically.

---

## 2. Running it locally (on your own computer)

1. Install [Node.js](https://nodejs.org) (version 18 or newer) if you don't
   have it.
2. Open a terminal in the `netheria-website` folder.
3. Install dependencies:
   ```
   npm install
   ```
4. Start the server:
   ```
   npm start
   ```
5. Open your browser to **http://localhost:3000**

You can also just double-click `index.html` to preview the design without
Node — but the music/copy-IP buttons work best when served by `server.js`
(some browsers block certain features on `file://` pages).

---

## 3. Uploading it to Glitch

1. Go to [glitch.com](https://glitch.com) and create a free account.
2. Click **New Project → Import from GitHub** if your files are on GitHub,
   **or** click **New Project → glitch-hello-node**, then delete the sample
   files it creates and upload yours instead:
   - In the Glitch editor, use the **Assets/Files** panel → drag and drop
     every file and folder from `netheria-website` into the project (keep
     the same folder structure, especially `/assets`).
3. Glitch automatically detects `package.json` and `server.js` and runs
   `npm start` for you. Your site will be live at
   `https://your-project-name.glitch.me` within a few seconds.
4. Every time you edit a file in the Glitch editor, the site updates
   automatically — no redeploy step needed.

---

## 4. Editing your content (`config.js`)

Open `config.js`. It's split into clearly labeled sections:

| Section | What it controls |
|---|---|
| `server` | Name, tagline, description, Java/Bedrock IP + port, version, online status, player counts |
| `links` | Discord invite, YouTube, TikTok |
| `music` | Background music file path + track name |
| `features` | The animated feature cards |
| `howToPlay` | The 3-step Java/Bedrock instructions |
| `faq` | Every FAQ question + answer |
| `rules` | The numbered rules list |
| `staff` | Team member names, roles, and photos |

To change anything, edit the text **inside the quotes** and save. Don't
delete commas, quotes, or brackets.

### Changing the server IP
```js
server: {
  ipJava: "play.netheria.net",      // ← change this
  ipBedrock: "play.netheria.net",   // ← and this
  portBedrock: "19132",
  portJava: "25565",
  ...
}
```
This automatically updates the hero section, the Server Information panel,
and the copy-IP buttons everywhere on the site.

### Changing the Discord link
```js
links: {
  discord: "https://discord.gg/your-invite-code",  // ← change this
  ...
}
```
This updates the navbar button, hero button, Community section, Server Info
panel, and footer — all from this one line.

### Adding your own music
1. Add a royalty-free `.mp3` or `.ogg` file to `assets/music/` (do **not**
   use copyrighted music you don't have rights to).
2. Update the file name in `config.js`:
   ```js
   music: {
     file: "assets/music/theme.mp3",   // ← match your file name exactly
     trackName: "Netheria Theme",
   }
   ```
3. Music never autoplays (browsers block it, and it's better UX anyway) —
   visitors click the speaker icon in the navbar to start it.

### Adding images (staff photos, favicon, social preview image)
- **Staff photos:** put an image in `assets/images/`, then in `config.js`:
  ```js
  { name: "YourName", role: "Owner", image: "assets/images/owner.png" }
  ```
  Leave `image: ""` to show colored initials instead of a photo.
- **Favicon:** replace `assets/icons/favicon.svg` with your own icon (or add
  a `.png` and update the `<link rel="icon">` tag in `index.html`).
- **Social preview image (Open Graph):** add `assets/images/og-cover.jpg`
  (recommended size 1200×630) — it's already referenced in `index.html`.

---

## 5. Changing colors and design

All colors, fonts and spacing live at the very top of `style.css` inside
`:root { ... }`. For example:

```css
:root {
  --portal: #9b5cf6;    /* nether portal purple accent */
  --magma: #ff6a3d;     /* lava orange accent */
  --glowstone: #ffcf6b; /* gold highlight */
  --void: #0b0912;      /* page background */
  --font-display: "Space Grotesk", "Inter", sans-serif;
}
```

Change any hex code or font name and the whole site updates, since every
component reuses these variables instead of hard-coded colors.

---

## 6. Live server status (optional, advanced)

By default, `server.status` / `playersOnline` / `playersMax` in `config.js`
are values **you** set by hand. If you want the numbers to update
automatically from your real Minecraft server, you can call a free status
API (like `api.mcsrvstat.us`) from `script.js`'s `updateStatus()` function
and replace the config values with the live response. This requires a
little JavaScript/fetch knowledge — ask a developer friend, or a follow-up
question, if you'd like this added.

---

## 7. Adding more pages/sections later

The site is a single scrolling page (a common, modern pattern for game
server sites). To add a new section:

1. Copy an existing `<section class="section"> ... </section>` block in
   `index.html` and change its `id` and content.
2. Add a matching link in the navbar (`.nav__links`) and mobile menu
   (`.mobile-menu`) pointing to `#your-new-section-id`.
3. Reuse existing CSS classes (`.section`, `.section__title`, `.glass`,
   `.btn`) so it matches the rest of the site automatically.

If you'd rather have a separate page (e.g. `store.html`), copy `index.html`
as a starting template, keep the same `<link>`/`<script>` tags at the top
and bottom, and just change the `<main>` content.

---

## 8. Credits & notes

- No copyrighted music or Minecraft assets are included — the "N" mark,
  fonts (Space Grotesk / Inter / JetBrains Mono via Google Fonts) and colors
  are all original/open-licensed.
- This site is a fan project and is **not affiliated with Mojang or
  Microsoft** (see footer).
