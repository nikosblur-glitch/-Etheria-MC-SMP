/**
 * ============================================================
 *  NETHERIA MC SMP — SERVER
 * ============================================================
 *  Serves the static site and exposes the shared config to the
 *  browser at /config.js, so config.js (root) stays the single
 *  source of truth for both server and client.
 * ============================================================
 */

const express = require("express");
const path = require("path");
const config = require("./config.js");

const app = express();
const PORT = process.env.PORT || 3000;

// ---- Serve the shared config to the browser as a global ------------------
app.get("/config.js", (req, res) => {
  res.type("application/javascript");
  res.send(`window.NETHERIA_CONFIG = ${JSON.stringify(config, null, 2)};`);
});

// ---- Simple status endpoint (placeholder data, ready for a real API) -----
// Wire this up to a real Minecraft server-status query later
// (e.g. the "minecraft-server-util" package) and set
// LIVE_STATUS_ENABLED to true in config.js once it's live.
app.get("/api/server-status", (req, res) => {
  res.json({
    online: true,
    players: config.PLAYER_COUNT,
    capacity: config.SERVER_CAPACITY,
    version: config.MINECRAFT_VERSION,
    live: config.LIVE_STATUS_ENABLED,
  });
});

// ---- Static assets ---------------------------------------------------------
app.use(express.static(path.join(__dirname, "public")));

app.listen(PORT, () => {
  console.log(`Netheria MC SMP website running on port ${PORT}`);
});
