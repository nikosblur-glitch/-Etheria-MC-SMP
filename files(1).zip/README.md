# Netheria MC SMP — Website

A premium, dark, glassmorphism website for the Netheria Minecraft SMP. Built with plain HTML/CSS/JS on a small Express server, ready to run on Glitch.

## 1. Everything you'll want to edit lives in `config.js`

Open **`config.js`** in the project root. That single file controls:

- `SERVER_NAME`, `SERVER_TAGLINE`, `SERVER_DESCRIPTION`
- `SERVER_IP`, `BEDROCK_IP`, `SERVER_PORT`, `BEDROCK_PORT`, `MINECRAFT_VERSION`, `BEDROCK_SUPPORTED`
- `DISCORD_INVITE`
- `PLAYER_COUNT`, `SERVER_CAPACITY`
- `STATS` (the About section numbers)
- `FEATURES`, `HOW_TO_PLAY`, `FAQ`, `RULES` (arrays — add/remove/edit items freely)
- `MUSIC_FILE`, `MUSIC_TRACK_NAME`
- `SEO` (title, description, Open Graph image, site URL)

You never need to touch the HTML, CSS, or JS to make these changes — the page reads `config.js` at load time.

## 2. Running it on Glitch

1. Go to [glitch.com](https://glitch.com) and create a **New Project → Import from GitHub** (if you've pushed this to GitHub), or **New Project → glitch-hello-node** and then replace every file with the ones in this project.
2. Upload the project files, keeping this exact structure:
   ```
   netheria-website/
   ├── package.json
   ├── server.js
   ├── config.js
   ├── README.md
   └── public/
       ├── index.html
       ├── style.css
       ├── script.js
       └── assets/
           ├── music/
           ├── images/
           └── icons/
   ```
3. Glitch automatically runs `npm install` and then `npm start` (which runs `node server.js`). You don't need to start anything manually — but if the app ever stalls, open the Glitch console (Tools → Terminal) and run `node server.js` yourself to see errors.
4. Your site is live at `https://YOUR_PROJECT_NAME.glitch.me`.

## 3. Change the Discord invite

In `config.js`, set:
```js
DISCORD_INVITE: "https://discord.gg/yourcode",
```
Every "Join Discord" button on the site (navbar, hero, community section, footer) pulls from this one value.

## 4. Add your Minecraft IP

In `config.js`:
```js
SERVER_IP: "play.yourdomain.com",       // Java
BEDROCK_IP: "play.yourdomain.com",      // Bedrock
SERVER_PORT: "25565",
BEDROCK_PORT: "19132",
MINECRAFT_VERSION: "1.21.x",
BEDROCK_SUPPORTED: true,                // set false to hide the Bedrock row entirely
```
The status widget and the **Copy IP** button both update automatically.

## 5. Add music

1. Drop your audio file at `public/assets/music/netheria.mp3` (this exact path works with zero code changes).
2. If you use a different filename, update `MUSIC_FILE` in `config.js` to match, e.g. `"/assets/music/my-track.mp3"`.
3. Music never autoplays (browsers block it anyway) — visitors press the music button in the bottom-left corner to start it.

## 6. Replace images

The site currently uses **no external/copyrighted images** — the hero portal, backgrounds, and icons are all CSS/SVG/canvas, so there's nothing required to replace. If you want to add your own:

- **Favicon:** add a file at `public/assets/icons/favicon.png` (already linked in `index.html`).
- **Open Graph preview image:** add `public/assets/images/og-cover.jpg` and it will be picked up automatically (already linked in `index.html`, path also set in `config.js` under `SEO.OG_IMAGE`).
- Any other image you add: place it in `public/assets/images/` and reference it with `<img src="/assets/images/yourfile.jpg">` wherever you'd like in `public/index.html`.

## 7. Customize colors

All colors are defined once at the top of `public/style.css` under `:root`, for example:
```css
--purple-glow: #b06bff;
--crimson: #b81c38;
--gold: #f0a83c;
```
Change these hex values and the whole site (buttons, glows, gradients, borders) updates consistently.

## 8. Customize text

- Section headings, hero text, and the About/Discord copy live directly in `public/index.html` (search for the section you want, e.g. `id="about"`).
- List-based content (Features, How to Play, FAQ, Rules, Stats) lives in `config.js` — edit the arrays there instead of the HTML.

## 9. Local development

```bash
npm install
npm start
```
Then open `http://localhost:3000`.

## 10. Project structure

```
netheria-website/
│
├── package.json        # dependencies + start script
├── server.js            # Express server, serves /config.js and static files
├── config.js             # ← single source of truth, edit this first
├── README.md
│
└── public/
    ├── index.html        # page structure + SEO metadata
    ├── style.css          # design system (colors, type, layout, animations)
    ├── script.js           # renders config-driven content + all interactions
    └── assets/
        ├── music/netheria.mp3   # your track goes here
        ├── images/                # your OG image / extra images go here
        └── icons/favicon.png      # your favicon goes here
```

## Notes

- No social media platforms are linked anywhere on the site except Discord, by design.
- The server-status widget currently shows placeholder data from `config.js`. If you want live player counts, wire `app.get("/api/server-status", ...)` in `server.js` up to a package like `minecraft-server-util`, then set `LIVE_STATUS_ENABLED: true` in `config.js` and have `public/script.js` poll `/api/server-status`.
- Reduced-motion is respected — visitors with that OS setting get a calmer, near-static version of the animations.
