/* ============================================================
   NETHERIA MC SMP — CLIENT SCRIPT
   Reads window.NETHERIA_CONFIG (from /config.js) and renders
   every editable piece of content + wires up all interactions.
   ============================================================ */

(() => {
  "use strict";

  const CFG = window.NETHERIA_CONFIG || {};

  /* ---------------------------------------------------------
     Helpers
  --------------------------------------------------------- */
  const $ = (sel, ctx = document) => ctx.querySelector(sel);
  const $$ = (sel, ctx = document) => Array.from(ctx.querySelectorAll(sel));

  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  /* ---------------------------------------------------------
     1. Apply simple text config bindings ([data-config])
  --------------------------------------------------------- */
  function applyTextConfig() {
    $$("[data-config]").forEach((node) => {
      const key = node.getAttribute("data-config");
      if (CFG[key] !== undefined) node.textContent = CFG[key];
    });

    document.title = (CFG.SEO && CFG.SEO.TITLE) || document.title;

    // Discord links
    const discordHref = CFG.DISCORD_INVITE || "#";
    ["navDiscordBtn", "navDiscordBtnMobile", "heroDiscordBtn", "communityDiscordBtn", "footerDiscordBtn"].forEach((id) => {
      const node = document.getElementById(id);
      if (node) node.href = discordHref;
    });

    const heroPlay = document.getElementById("heroPlayBtn");
    if (heroPlay) heroPlay.href = "#status";
  }

  /* ---------------------------------------------------------
     2. Render list-based sections from config
  --------------------------------------------------------- */
  function renderStats() {
    const grid = document.getElementById("statsGrid");
    if (!grid || !Array.isArray(CFG.STATS)) return;
    grid.innerHTML = "";
    CFG.STATS.forEach((s) => {
      const card = el("div", "stat-card glass");
      card.appendChild(el("span", "stat-card__value", s.value));
      card.appendChild(el("span", "stat-card__label", s.label));
      grid.appendChild(card);
    });
  }

  function renderFeatures() {
    const grid = document.getElementById("featuresGrid");
    if (!grid || !Array.isArray(CFG.FEATURES)) return;
    grid.innerHTML = "";
    CFG.FEATURES.forEach((f) => {
      const card = el("div", "feature-card glass reveal");
      card.appendChild(el("span", "feature-card__icon", f.icon || ""));
      card.appendChild(el("h3", "feature-card__title", f.title));
      card.appendChild(el("p", "feature-card__desc", f.description));
      card.addEventListener("mousemove", (e) => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty("--mx", `${e.clientX - rect.left}px`);
        card.style.setProperty("--my", `${e.clientY - rect.top}px`);
      });
      grid.appendChild(card);
    });
  }

  function renderSteps() {
    const list = document.getElementById("stepsList");
    if (!list || !Array.isArray(CFG.HOW_TO_PLAY)) return;
    list.innerHTML = "";
    CFG.HOW_TO_PLAY.forEach((s) => {
      const card = el("div", "step-card glass reveal");
      card.appendChild(el("span", "step-card__num", `STEP ${s.step}`));
      card.appendChild(el("h3", "step-card__title", s.title));
      card.appendChild(el("p", "step-card__desc", s.description));
      list.appendChild(card);
    });
  }

  function renderRules() {
    const list = document.getElementById("rulesList");
    if (!list || !Array.isArray(CFG.RULES)) return;
    list.innerHTML = "";
    CFG.RULES.forEach((rule, i) => {
      const card = el("div", "rule-card glass reveal");
      card.appendChild(el("span", "rule-card__num", String(i + 1).padStart(2, "0")));
      card.appendChild(el("span", "rule-card__text", rule));
      list.appendChild(card);
    });
  }

  function renderFaq() {
    const list = document.getElementById("faqList");
    if (!list || !Array.isArray(CFG.FAQ)) return;
    list.innerHTML = "";
    CFG.FAQ.forEach((item) => {
      const wrap = el("div", "faq-item glass reveal");
      const btn = el("button", "faq-item__q");
      btn.setAttribute("aria-expanded", "false");
      btn.innerHTML = `<span>${item.q}</span><span class="faq-item__icon"></span>`;
      const aWrap = el("div", "faq-item__a-wrap");
      const a = el("p", "faq-item__a", item.a);
      aWrap.appendChild(a);
      wrap.appendChild(btn);
      wrap.appendChild(aWrap);

      btn.addEventListener("click", () => {
        const isOpen = wrap.classList.toggle("is-open");
        btn.setAttribute("aria-expanded", String(isOpen));
        aWrap.style.maxHeight = isOpen ? `${aWrap.scrollHeight}px` : "0px";
      });

      list.appendChild(wrap);
    });
  }

  /* ---------------------------------------------------------
     3. Server status widget
  --------------------------------------------------------- */
  function renderStatus() {
    const players = document.getElementById("statPlayers");
    const version = document.getElementById("statVersion");
    const javaIp = document.getElementById("statJavaIp");
    const bedrockIp = document.getElementById("statBedrockIp");
    const bedrockRow = document.getElementById("bedrockRow");

    if (players) players.textContent = `${CFG.PLAYER_COUNT ?? 0} / ${CFG.SERVER_CAPACITY ?? 100}`;
    if (version) version.textContent = CFG.MINECRAFT_VERSION || "YOUR VERSION";
    if (javaIp) {
      const port = CFG.SERVER_PORT && CFG.SERVER_PORT !== "25565" ? `:${CFG.SERVER_PORT}` : "";
      javaIp.textContent = `${CFG.SERVER_IP || "YOUR_SERVER_IP"}${port}`;
    }
    if (bedrockRow) bedrockRow.style.display = CFG.BEDROCK_SUPPORTED ? "" : "none";
    if (bedrockIp) {
      const bport = CFG.BEDROCK_PORT ? `:${CFG.BEDROCK_PORT}` : "";
      bedrockIp.textContent = `${CFG.BEDROCK_IP || "YOUR_BEDROCK_IP"}${bport}`;
    }
  }

  function setupCopyIp() {
    const btn = document.getElementById("copyIpBtn");
    const label = document.getElementById("copyIpLabel");
    if (!btn) return;
    const original = label.textContent;

    btn.addEventListener("click", async () => {
      const ip = CFG.SERVER_IP || "YOUR_SERVER_IP";
      try {
        await navigator.clipboard.writeText(ip);
      } catch (e) {
        // Clipboard API unavailable — fall back silently, UI still confirms intent.
      }
      label.textContent = "IP Copied \u2713";
      btn.classList.add("btn--primary");
      showToast("Server IP copied to clipboard");
      setTimeout(() => { label.textContent = original; }, 2000);
    });
  }

  /* ---------------------------------------------------------
     4. Loading screen
  --------------------------------------------------------- */
  function runLoader() {
    const loader = document.getElementById("loader");
    const fill = document.getElementById("loaderFill");
    if (!loader) return;

    let progress = 0;
    const tick = () => {
      progress = Math.min(100, progress + Math.random() * 18 + 6);
      if (fill) fill.style.width = `${progress}%`;
      if (progress < 100) {
        setTimeout(tick, 140);
      } else {
        setTimeout(() => {
          loader.classList.add("is-hidden");
          document.body.classList.add("is-loaded");
        }, 200);
      }
    };
    setTimeout(tick, 200);
  }

  /* ---------------------------------------------------------
     5. Nav: scroll state + mobile menu
  --------------------------------------------------------- */
  function setupNav() {
    const nav = document.getElementById("siteNav");
    const toggle = document.getElementById("navToggle");
    const mobile = document.getElementById("navMobile");

    const onScroll = () => {
      if (window.scrollY > 40) nav.classList.add("is-scrolled");
      else nav.classList.remove("is-scrolled");
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    if (toggle && mobile) {
      toggle.addEventListener("click", () => {
        const isOpen = mobile.classList.toggle("is-open");
        toggle.setAttribute("aria-expanded", String(isOpen));
      });
      $$("#navMobile a").forEach((link) =>
        link.addEventListener("click", () => {
          mobile.classList.remove("is-open");
          toggle.setAttribute("aria-expanded", "false");
        })
      );
    }
  }

  /* ---------------------------------------------------------
     6. Scroll progress bar + back to top
  --------------------------------------------------------- */
  function setupScrollChrome() {
    const fill = document.getElementById("scrollProgressFill");
    const backToTop = document.getElementById("backToTop");

    const onScroll = () => {
      const scrollTop = window.scrollY;
      const height = document.documentElement.scrollHeight - window.innerHeight;
      const pct = height > 0 ? (scrollTop / height) * 100 : 0;
      if (fill) fill.style.width = `${pct}%`;
      if (backToTop) backToTop.classList.toggle("is-visible", scrollTop > 600);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });

    if (backToTop) {
      backToTop.addEventListener("click", () => {
        window.scrollTo({ top: 0, behavior: "smooth" });
      });
    }
  }

  /* ---------------------------------------------------------
     7. Scroll reveal (IntersectionObserver)
  --------------------------------------------------------- */
  function setupReveal() {
    const targets = $$(".reveal");
    if (!("IntersectionObserver" in window) || targets.length === 0) {
      targets.forEach((t) => t.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            const target = entry.target;
            setTimeout(() => target.classList.add("is-visible"), (i % 6) * 70);
            observer.unobserve(target);
          }
        });
      },
      { threshold: 0.15, rootMargin: "0px 0px -60px 0px" }
    );
    targets.forEach((t) => observer.observe(t));
  }

  /* ---------------------------------------------------------
     8. Cursor glow (desktop only)
  --------------------------------------------------------- */
  function setupCursorGlow() {
    const glow = document.getElementById("cursorGlow");
    if (!glow || window.matchMedia("(hover: none)").matches) return;
    window.addEventListener(
      "mousemove",
      (e) => {
        glow.style.transform = `translate(${e.clientX}px, ${e.clientY}px) translate(-50%, -50%)`;
      },
      { passive: true }
    );
  }

  /* ---------------------------------------------------------
     9. Ambient particle field (canvas)
  --------------------------------------------------------- */
  function setupParticles() {
    const canvas = document.getElementById("particleField");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let particles = [];
    let width, height;
    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function resize() {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    }

    function makeParticles() {
      const count = Math.min(70, Math.floor((width * height) / 22000));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        r: Math.random() * 1.6 + 0.4,
        speed: Math.random() * 0.35 + 0.08,
        drift: (Math.random() - 0.5) * 0.25,
        hue: Math.random() > 0.5 ? "176,107,255" : "255,90,120",
        alpha: Math.random() * 0.5 + 0.15,
      }));
    }

    function frame() {
      ctx.clearRect(0, 0, width, height);
      particles.forEach((p) => {
        p.y -= p.speed;
        p.x += p.drift;
        if (p.y < -10) { p.y = height + 10; p.x = Math.random() * width; }
        if (p.x < -10) p.x = width + 10;
        if (p.x > width + 10) p.x = -10;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${p.hue},${p.alpha})`;
        ctx.shadowColor = `rgba(${p.hue},0.8)`;
        ctx.shadowBlur = 6;
        ctx.fill();
      });
      requestAnimationFrame(frame);
    }

    resize();
    makeParticles();
    window.addEventListener("resize", () => { resize(); makeParticles(); });

    if (!reducedMotion) requestAnimationFrame(frame);
  }

  /* ---------------------------------------------------------
     10. Music player
  --------------------------------------------------------- */
  function setupMusic() {
    const player = document.getElementById("musicPlayer");
    const toggle = document.getElementById("musicToggle");
    const audio = document.getElementById("musicAudio");
    const volume = document.getElementById("musicVolume");
    const trackName = document.getElementById("musicTrackName");

    if (!player || !audio) return;

    audio.src = CFG.MUSIC_FILE || "/assets/music/netheria.mp3";
    audio.volume = (Number(volume?.value) || 40) / 100;
    if (trackName) trackName.textContent = CFG.MUSIC_TRACK_NAME || "Netheria — Ambient Theme";

    toggle.addEventListener("click", async () => {
      if (audio.paused) {
        try {
          await audio.play();
          player.classList.add("is-playing");
        } catch (e) {
          showToast("Add a track at /assets/music/netheria.mp3 to enable music");
        }
      } else {
        audio.pause();
        player.classList.remove("is-playing");
      }
    });

    volume?.addEventListener("input", () => {
      audio.volume = Number(volume.value) / 100;
    });
  }

  /* ---------------------------------------------------------
     11. Toast notifications
  --------------------------------------------------------- */
  let toastTimer;
  function showToast(message) {
    const toast = document.getElementById("toast");
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add("is-visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("is-visible"), 2600);
  }

  /* ---------------------------------------------------------
     12. Footer year
  --------------------------------------------------------- */
  function setupFooter() {
    const year = document.getElementById("footerYear");
    if (year) year.textContent = new Date().getFullYear();
  }

  /* ---------------------------------------------------------
     Init
  --------------------------------------------------------- */
  document.addEventListener("DOMContentLoaded", () => {
    applyTextConfig();
    renderStats();
    renderFeatures();
    renderSteps();
    renderRules();
    renderFaq();
    renderStatus();
    setupCopyIp();
    setupNav();
    setupScrollChrome();
    setupCursorGlow();
    setupParticles();
    setupMusic();
    setupFooter();
    runLoader();

    // Re-run reveal setup after dynamic content is in the DOM
    requestAnimationFrame(setupReveal);
  });
})();
