/**
 * ============================================================
 *  NETHERIA MC SMP — CENTRAL CONFIGURATION
 * ============================================================
 *  Edit THIS file to change anything important about the site.
 *  You should never need to touch HTML/CSS/JS for basic changes.
 * ============================================================
 */

module.exports = {
  // ---- SERVER IDENTITY ----------------------------------------------------
  SERVER_NAME: "NETHERIA",
  SERVER_TAGLINE: "ENTER THE WORLD. BUILD YOUR LEGACY.",
  SERVER_DESCRIPTION:
    "Netheria is a survival SMP built for players who want a world that remembers them — permanent builds, a living economy, and a community that plays together every day.",

  // ---- CONNECTION DETAILS (placeholders — replace with real values) ------
  // Java Edition IP shown on the site + used by the Copy IP button.
  SERVER_IP: "YOUR_SERVER_IP",
  // Bedrock Edition IP (leave as-is if you don't support Bedrock).
  BEDROCK_IP: "YOUR_BEDROCK_IP",
  // Port. Java default is 25565, Bedrock default is 19132.
  SERVER_PORT: "25565",
  BEDROCK_PORT: "19132",
  // Supported Minecraft version(s), shown in the status widget + FAQ.
  MINECRAFT_VERSION: "YOUR_VERSION",
  // Whether to show the Bedrock IP block at all.
  BEDROCK_SUPPORTED: true,

  // ---- DISCORD -------------------------------------------------------------
  // Full invite URL, e.g. "https://discord.gg/abc123"
  DISCORD_INVITE: "YOUR_DISCORD_INVITE",

  // ---- PLAYER COUNT (placeholder UI — wire up to a real query later) ------
  PLAYER_COUNT: 0,
  SERVER_CAPACITY: 100,
  // If you don't have a live status API yet, keep this false —
  // the widget will show the placeholder numbers above instead of polling.
  LIVE_STATUS_ENABLED: false,

  // ---- ABOUT STATS ----------------------------------------------------------
  STATS: [
    { value: "0+", label: "PLAYERS" },
    { value: "24/7", label: "ADVENTURE" },
    { value: "1", label: "UNIQUE WORLD" },
    { value: "\u221E", label: "POSSIBILITIES" },
  ],

  // ---- MUSIC ----------------------------------------------------------------
  // Drop your track at public/assets/music/netheria.mp3 — same filename
  // works with no code changes. Change the path here if you rename it.
  MUSIC_FILE: "/assets/music/netheria.mp3",
  MUSIC_TRACK_NAME: "Netheria — Ambient Theme",

  // ---- FEATURES ---------------------------------------------------------
  FEATURES: [
    { icon: "\u2694\uFE0F", title: "Survival SMP", description: "A true survival world with permanent builds, real consequences, and no resets." },
    { icon: "\uD83D\uDCB0", title: "Economy", description: "A player-driven economy — earn, trade, and build your fortune from the ground up." },
    { icon: "\uD83C\uDFEA", title: "Player Shops", description: "Open your own shop and sell what you craft, farm, or find in the world." },
    { icon: "\uD83C\uDF0E", title: "Exploration", description: "Vast, unexplored terrain waiting to be discovered — chart your own path." },
    { icon: "\uD83C\uDFAF", title: "Quests", description: "Hand-crafted quests and storylines that reward you for playing your way." },
    { icon: "\uD83C\uDF89", title: "Events", description: "Regular community events with prizes, competitions, and unforgettable moments." },
    { icon: "\uD83D\uDC65", title: "Community", description: "A close-knit community of players who build, trade, and adventure together." },
    { icon: "\uD83C\uDFC6", title: "Ranks", description: "Progress through ranks and unlock new perks as you grow with the server." },
    { icon: "\uD83D\uDD25", title: "Custom Features", description: "Hand-picked custom mechanics that keep survival fresh, without losing vanilla's soul." },
  ],

  // ---- HOW TO PLAY STEPS ----------------------------------------------------
  HOW_TO_PLAY: [
    { step: "01", title: "Open Minecraft", description: "Launch Minecraft Java or Bedrock Edition on your device." },
    { step: "02", title: "Add the Server", description: "Add Netheria using the server address shown below." },
    { step: "03", title: "Join Netheria", description: "Select Netheria from your server list and hit join." },
    { step: "04", title: "Start Your Adventure", description: "Spawn in, meet the community, and start building your legacy." },
  ],

  // ---- FAQ --------------------------------------------------------------
  FAQ: [
    { q: "What is Netheria MC SMP?", a: "Netheria is a survival multiplayer Minecraft server focused on long-term worlds, a player economy, and a genuine community — no resets, no pay-to-win." },
    { q: "How do I join?", a: "Add our server address in your Minecraft multiplayer menu and hit join. See the \u201CHow to Play\u201D section above for the full walkthrough." },
    { q: "What Minecraft versions are supported?", a: "Check the server status widget above for the currently supported version — we keep this updated as we upgrade." },
    { q: "Can Bedrock players join?", a: "Yes — Bedrock Edition players can join using the Bedrock address and port listed in the server status widget." },
    { q: "Is Netheria free?", a: "Yes, joining and playing Netheria is completely free. Optional cosmetic support may be available in the future." },
    { q: "Where can I get support?", a: "Join our Discord community — our team and fellow players are there to help with anything you need." },
    { q: "How can I become staff?", a: "We open staff applications periodically in our Discord. Keep an eye on the announcements channel for openings." },
  ],

  // ---- RULES --------------------------------------------------------------
  RULES: [
    "Respect everyone. No harassment, hate speech, or personal attacks.",
    "No cheating. No hacked clients, X-ray, or unfair automation.",
    "No exploiting. Report bugs instead of abusing them.",
    "No spam. Keep chat and builds clean and readable.",
    "Follow staff instructions and the wider server rules at all times.",
  ],

  // ---- SOCIAL / COMMUNITY ---------------------------------------------------
  // Discord is intentionally the only external platform linked from this site.

  // ---- SEO / METADATA -------------------------------------------------------
  SEO: {
    TITLE: "Netheria MC SMP — Enter the World. Build Your Legacy.",
    DESCRIPTION: "Netheria is a premium Minecraft survival SMP with a living economy, player shops, quests, and a community that builds together. Join free on Java & Bedrock.",
    OG_IMAGE: "/assets/images/og-cover.jpg",
    THEME_COLOR: "#0a0610",
    SITE_URL: "https://YOUR_GLITCH_PROJECT.glitch.me",
  },
};
